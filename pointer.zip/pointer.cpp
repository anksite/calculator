#include <iostream>
using namespace std;
main(){
	int n = 33;
	cout << "n = "<< n<<endl;
	cout << "&n = "<< &n<<endl;
}

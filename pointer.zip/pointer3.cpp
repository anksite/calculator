#include <iostream>
using namespace std;

main(){
	int nilai[3], *p;
	nilai[0] = 125;
	nilai[1] = 345;
	nilai[2] = 750;
	
	p = &nilai[0];
	
	cout<<"Nilai pointer "<<*p<<"  Alamat "<<p<<endl;
	cout<<"Nilai pointer "<<*(p+1)<<"  Alamat "<<p+1<<endl;
	cout<<"Nilai pointer "<<*(p+2)<<"  Alamat "<<p+2<<endl;
}

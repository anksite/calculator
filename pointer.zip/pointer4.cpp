#include <iostream>
using namespace std;

main(){
	int a = 100, b = 200, *pa, *pb;
	pa = &a;
	pb = &b;
	
	if(pa < pb){
		cout<<"pa lebih rendah dari pb"<<endl;
	}
	
	if(pa > pb){
		cout<<"pa ("<<*pa<<") lebih besar dari pb ("<<pb<<")"<<endl;
	}
	
	if(pa < pb){
		cout<<"pa sama dengan pb"<<endl;
	}
}

#include <iostream>
using namespace std;
main(){
	float *x1, *x2, y;
	y = 13.45;
	
	x1 = &y;
	x2 = x1;
	
	cout << "Nilai y = "<<y<<" alamat"<<x1<<endl;
	cout << "Nilai y = "<<y<<" alamat"<<x2<<endl;
}
